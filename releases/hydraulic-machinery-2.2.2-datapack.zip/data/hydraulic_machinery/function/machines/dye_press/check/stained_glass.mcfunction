execute \
    as @e[ \
        type=armor_stand, \
        tag=hydraulic_machinery_dye_marker, \
        tag=!hydraulic_machinery_active \
    ] \
    at @s \
    if block ~ ~1 ~ minecraft:sticky_piston[extended=true] \
    if block ~ ~-2 ~ #hydraulic_machinery:glass_blocks \
    run function hydraulic_machinery:machines/dye_press/color/stained_glass
