$setblock ~ ~ ~ $(block)
kill @s
